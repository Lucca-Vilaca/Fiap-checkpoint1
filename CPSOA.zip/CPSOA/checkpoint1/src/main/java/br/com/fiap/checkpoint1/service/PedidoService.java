package br.com.fiap.checkpoint1.service;

import br.com.fiap.checkpoint1.model.Pedido;
import br.com.fiap.checkpoint1.repository.PedidoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class PedidoService {

    @Autowired
    private PedidoRepository repository;

    public List<Pedido> listarTodos() {
        return repository.findAll();
    }

    public Pedido buscarPorId(Long id) {
        return repository.findById(id).orElseThrow(() -> new RuntimeException("Pedido não encontrado"));
    }

    public Pedido salvar(Pedido pedido) {
        pedido.setDataPedido(LocalDate.now());
        return repository.save(pedido);
    }

    public Pedido atualizar(Long id, Pedido atualizado) {
        Pedido existente = buscarPorId(id);
        existente.setClienteNome(atualizado.getClienteNome());
        existente.setValorTotal(atualizado.getValorTotal());
        return repository.save(existente);
    }

    public void deletar(Long id) {
        repository.deleteById(id);
    }
}
